import type { EngineDecision, NormalizedInput, Plate, Position } from "./types.js";

export type CreatorDomain = "environment" | "people" | "structures" | "forms";
export type CreatorLevel = "1" | "2" | "3" | "4";
export type CreatorDomainCode = "A" | "B" | "C" | "D";
export type CreatorCellKey = `${CreatorLevel}${CreatorDomainCode}`;

export interface CreatorCell { key: CreatorCellKey; title: string; mission: string; actions: readonly string[]; }
export interface CreatorOperation { opType: string; domain: CreatorDomain; inputs: readonly string[]; outputs: readonly string[]; note: string; }

export interface MaterializationArtifact {
  artifactId: string;
  kind: "creator-protocol";
  cell: CreatorCell;
  operation: CreatorOperation;
  domain: CreatorDomain;
  intention: string;
  field: { density: number; conductance: number; source: string };
  vector: { direction: string; magnitude: number; quality: number };
  specification: { title: string; objective: string; nextAction: string; constraints: string[] };
  domainResult: Record<string, unknown>;
  sourceDecisionId: string;
  createdAt: string;
}

export interface CreatorPort { materialize(decision: EngineDecision, makeId: () => string, now: () => Date): Promise<MaterializationArtifact>; }

const LEVEL_BY_POSITION: Record<Position, CreatorLevel> = { P1: "1", P2: "2", P3: "3", P4: "4" };
const DOMAIN_BY_PLATE: Record<Plate, { code: CreatorDomainCode; domain: CreatorDomain }> = {
  "РЕСУРС": { code: "A", domain: "environment" }, "ВЛАСТЬ": { code: "B", domain: "people" }, "ОТНОШЕНИЯ": { code: "C", domain: "structures" }, "РЕЗУЛЬТАТ": { code: "D", domain: "forms" },
};

const cell = (key: CreatorCellKey, title: string, mission: string, actions: string[]): CreatorCell => ({ key, title, mission, actions });
export const CREATOR_CELLS: Readonly<Record<CreatorCellKey, CreatorCell>> = Object.freeze({
  "1A": cell("1A", "Тело → Среда", "Создать базу, которая не конфликтует с внутренней системой.", ["Убрать физиологический шум.", "Настроить свет, воздух, тишину и температуру.", "Проверить сжатие и раскрытие тела."]),
  "1B": cell("1B", "Тело → Люди", "Отсеивать несовместимых людей до включения психики.", ["Использовать тело как радар.", "Не входить глубоко при телесном отказе.", "Различить резонанс и помеху."]),
  "1C": cell("1C", "Тело → Структуры", "Создавать структуры, работающие на плотность.", ["Проверить проект телом.", "Согласовать ритм с физиологией.", "Составить карту нагрузки."]),
  "1D": cell("1D", "Тело → Формы", "Создавать физиологически валидные формы.", ["Проверить форму телесным ощущением.", "Найти места искажения.", "Скорректировать форму до естественности."]),
  "2A": cell("2A", "Эмоции → Среда", "Среда усиливает эмоциональную амплитуду.", ["Освободить движение волны.", "Убрать подавляющие зоны.", "Добавить частотные якоря."]),
  "2B": cell("2B", "Эмоции → Люди", "Создать поле влияния без давления.", ["Сохранить эмоциональную прозрачность.", "Передать энергию без принуждения.", "Собрать сценарий контакта."]),
  "2C": cell("2C", "Эмоции → Структуры", "Удерживать только живые структуры.", ["Проверить жизненную силу проектов.", "Остановить мёртвые хвосты.", "Связать импульс и действие."]),
  "2D": cell("2D", "Эмоции → Формы", "Создавать формы, вызывающие переживание.", ["Определить требуемую эмоцию.", "Встроить волну в форму.", "Проверить качество отклика."]),
  "3A": cell("3A", "Мышление → Среда", "Среда работает как инструмент мышления.", ["Разделить пространство на зоны.", "Минимизировать шум.", "Собрать ясную карту среды."]),
  "3B": cell("3B", "Мышление → Люди", "Создать архитектуру отношений.", ["Определить функциональные роли.", "Различить ресурс, шум и катализатор.", "Собрать матрицу взаимодействий."]),
  "3C": cell("3C", "Мышление → Структуры", "Создать самодостаточную экосистему.", ["Выделить ядро и модули.", "Описать связи и интерфейсы.", "Замкнуть рабочие циклы."]),
  "3D": cell("3D", "Мышление → Формы", "Сделать форму строгой и ясной.", ["Выделить ядро функции.", "Удалить шум.", "Проверить минимальную полноту."]),
  "4A": cell("4A", "Творец → Среда", "Материализовать в среде космологию и вектор.", ["Определить символы и цвета.", "Собрать world-space brief.", "Сделать среду порталом."]),
  "4B": cell("4B", "Творец → Люди", "Создать изменяющее поле субъективности.", ["Сформулировать частоту передачи.", "Создать приглашение без давления.", "Проверить изменение состояния."]),
  "4C": cell("4C", "Творец → Структуры", "Создать онтологию, в которой живут продукты.", ["Определить ядро мира.", "Собрать карту узлов и связей.", "Описать траектории входа."]),
  "4D": cell("4D", "Творец → Формы", "Создать кристалл смысла, доступный другим.", ["Выделить смысловое ядро.", "Собрать спецификацию артефакта.", "Сформировать портал в систему."]),
});

const op = (opType: string, domain: CreatorDomain, inputs: string[], outputs: string[], note: string): CreatorOperation => ({ opType, domain, inputs, outputs, note });
export const CREATOR_OPERATIONS: Readonly<Record<CreatorCellKey, CreatorOperation>> = Object.freeze({
  "1A": op("environment_cleanup", "environment", ["intention", "field"], ["checklist", "space_changes"], "Разбор среды по телесному соответствию."),
  "1B": op("people_filter_by_body", "people", ["intention", "field"], ["allow_list", "block_list"], "Фильтрация по телесному резонансу."),
  "1C": op("structure_rhythm_scan", "structures", ["intention", "field"], ["structure_risks", "load_map"], "Проверка ритма структуры."),
  "1D": op("form_somatic_validation", "forms", ["intention", "field"], ["valid_forms", "to_adjust"], "Соматика как валидатор формы."),
  "2A": op("emotional_tuning_space", "environment", ["intention", "field"], ["mood_settings", "anchors"], "Настройка среды под волну."),
  "2B": op("emotional_channeling", "people", ["intention", "vector"], ["message_tone", "interaction_script"], "Проведение эмоции в контакте."),
  "2C": op("project_lifeforce_check", "structures", ["intention", "field", "vector"], ["alive_projects", "dead_projects"], "Проверка жизненной силы."),
  "2D": op("form_emotional_charge", "forms", ["intention", "vector"], ["text_prompts", "emotion_hooks"], "Эмоциональный заряд формы."),
  "3A": op("workspace_architecture", "environment", ["intention"], ["zones_map", "layout_principles"], "Среда как продолжение мысли."),
  "3B": op("role_mapping", "people", ["intention", "field"], ["roles_matrix", "relationship_types"], "Карта ролей и функций."),
  "3C": op("ecosystem_design", "structures", ["intention", "vector"], ["modules", "links", "cycles"], "Проектирование экосистемы."),
  "3D": op("form_minimal_design", "forms", ["intention", "field"], ["core_elements", "to_remove"], "Очистка формы до функции."),
  "4A": op("worldspace_manifestation", "environment", ["intention", "vector"], ["symbol_set", "world_space_brief"], "Среда как портал в мир."),
  "4B": op("field_transmission", "people", ["intention", "vector"], ["field_statement", "invitation_frame"], "Передача состояния через поле."),
  "4C": op("ontology_construction", "structures", ["intention", "vector"], ["ontology_core", "world_map"], "Построение мира и системы."),
  "4D": op("meaning_crystalization", "forms", ["intention", "vector", "field"], ["artifact_specs", "spell_frame"], "Форма как кристалл смысла."),
});

export function resolveCreatorCell(input: NormalizedInput): CreatorCellKey {
  const position = input.position ?? "P1";
  return `${LEVEL_BY_POSITION[position]}${DOMAIN_BY_PLATE[input.plate].code}` as CreatorCellKey;
}

function domainResult(cell: CreatorCell, operation: CreatorOperation, input: NormalizedInput, direction: string): Record<string, unknown> {
  const base = { operation: operation.opType, mission: cell.mission, actions: [...cell.actions] };
  if (operation.domain === "environment") return { ...base, environmentBrief: { desiredState: input.intention, changes: cell.actions, anchors: [input.objectLabel ?? direction, input.geometry ?? "Euclid"] } };
  if (operation.domain === "people") return { ...base, peopleProtocol: { fieldStatement: input.intention, interactionFrame: direction, roles: ["subject", "counterpart", "observer"] } };
  if (operation.domain === "structures") return { ...base, structureMap: { core: input.intention, modules: ["core", "transition", "feedback"], links: ["core->transition", "transition->feedback", "feedback->core"] } };
  return { ...base, formSpec: { core: input.intention, format: input.imageLabel ?? "artifact", remove: ["noise", "duplication", "unverified claims"] } };
}

export class DeterministicCreator implements CreatorPort {
  async materialize(decision: EngineDecision, makeId: () => string, now: () => Date): Promise<MaterializationArtifact> {
    if (!decision.allow || !decision.normalizedInput) throw new Error("materialization requires an allowed decision");
    const input = decision.normalizedInput;
    const cellKey = resolveCreatorCell(input);
    const creatorCell = CREATOR_CELLS[cellKey];
    const operation = CREATOR_OPERATIONS[cellKey];
    const conductance = (input.metrics.alpha + input.metrics.Q + input.metrics.T) / 3;
    const density = Math.min(1, input.intention.length / 160);
    const direction = input.inversion?.trim() || input.objectLabel?.trim() || "materialize intention";
    const nextAction = creatorCell.actions[0] ?? "Собрать минимальную проверяемую форму результата.";
    return {
      artifactId: makeId(), kind: "creator-protocol", cell: creatorCell, operation, domain: operation.domain, intention: input.intention,
      field: { density, conductance, source: input.induction?.trim() || input.intention },
      vector: { direction, magnitude: input.metrics.T, quality: input.metrics.Q },
      specification: { title: input.objectLabel?.trim() || input.intention.slice(0, 80), objective: creatorCell.mission, nextAction, constraints: [`policy=${decision.policyVersion}`, `gate=${decision.gate}`, `context=${input.context}`, `cell=${cellKey}`] },
      domainResult: domainResult(creatorCell, operation, input, direction), sourceDecisionId: decision.decisionId, createdAt: now().toISOString(),
    };
  }
}
