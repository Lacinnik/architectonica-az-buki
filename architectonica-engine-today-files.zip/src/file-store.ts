import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { PersistentStore, emptyState, migrateStoreState, type StoreState } from "./store.js";

export class JsonFileStore extends PersistentStore {
  private writeQueue: Promise<void> = Promise.resolve();
  constructor(private readonly filePath: string) { super(); }
  protected async readState(): Promise<StoreState> {
    await this.writeQueue;
    try {
      return migrateStoreState(JSON.parse(await readFile(this.filePath, "utf8")));
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return emptyState();
      throw error;
    }
  }
  protected async writeState(state: StoreState): Promise<void> {
    const operation = this.writeQueue.then(async () => {
      await mkdir(dirname(this.filePath), { recursive: true });
      const temporary = `${this.filePath}.tmp`;
      await writeFile(temporary, JSON.stringify(state, null, 2), "utf8");
      await rename(temporary, this.filePath);
    });
    this.writeQueue = operation;
    await operation;
  }
}
