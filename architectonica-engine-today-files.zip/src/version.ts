import { CATALOG_VERSION } from "./catalog.js";
import { POLICY_VERSION } from "./policy.js";

export const ENGINE_VERSION = "architectonica-engine/0.1.0";
export const STORE_SCHEMA_VERSION = 2 as const;
export const VERSION_MANIFEST = Object.freeze({
  engine: ENGINE_VERSION,
  policy: POLICY_VERSION,
  catalog: CATALOG_VERSION,
  storeSchema: STORE_SCHEMA_VERSION,
});
