import type { Plate } from "./types.js";

export interface Card { id: string; plate: Plate; process: string; processIndex: number; position: "I" | "II" | "III" | "IV"; }
export interface Az { id: `A${number}`; title: string; }
export interface Buka { id: `B${number}`; symbol: string; title: string; }
export interface Transmission { id: `TX${number}`; title: string; focus: string; }

const PROCESS_MATRIX = {
  "РЕСУРС": ["БАЗОВЫЕ ПОТРЕБНОСТИ", "ДОБЫВАТЬ ЗАЩИТУ", "ПРОДОЛЖАТЬ РОД", "УЛУЧШАТЬ УСЛОВИЯ", "РАЗВИВАТЬ ТЕХНИКУ", "ДОБИВАТЬСЯ УСПЕХА"],
  "ВЛАСТЬ": ["ОБЕСПЕЧЬ БЕЗОПАСНОСТЬ", "СОХРАНИ СЕМЬЮ", "ЗАЩИТИ РОД", "ВОССТАНОВИ ВНИМАНИЕ", "ЦЕНИ РАВЕНСТВО", "ОТВЕЧАЙ НА ЧУВСТВА"],
  "ОТНОШЕНИЯ": ["БРОСАТЬ ВЫЗОВ", "УТВЕРЖДАТЬ СЕБЯ", "СТРЕМИТЬСЯ К ДЕЙСТВИЮ", "СТРЕМИТЬСЯ К РАВНОВЕСИЮ", "СОЗДАВАТЬ СИСТЕМЫ", "ЦЕНИТЬ ЕСТЕСТВЕННОСТЬ"],
  "РЕЗУЛЬТАТ": ["АДАПТИРОВАТЬСЯ К ВЕРОВАНИЯМ", "ЖЕРТВОВАТЬ ИНТЕРЕСАМИ", "СОБЛЮДАТЬ ДИСЦИПЛИНУ", "БЫТЬ В МОДЕЛИ ЦЕЛОГО", "СОЕДИНЯТЬ ТОЧКИ", "ВОССТАНАВЛИВАТЬ ДУХОВНОСТЬ"]
} as const satisfies Record<Plate, readonly string[]>;

const PREFIX: Record<Plate, string> = { "РЕСУРС": "R", "ВЛАСТЬ": "P", "ОТНОШЕНИЯ": "C", "РЕЗУЛЬТАТ": "O" };
const POSITIONS = ["I", "II", "III", "IV"] as const;

export const CARDS: readonly Card[] = (Object.entries(PROCESS_MATRIX) as [Plate, readonly string[]][]).flatMap(([plate, processes]) =>
  processes.flatMap((process, processIndex) => POSITIONS.map((position, positionIndex) => ({
    id: `${PREFIX[plate]}-${String(processIndex * 4 + positionIndex + 1).padStart(2, "0")}`,
    plate,
    process,
    processIndex: processIndex + 1,
    position
  })))
);

const AZ_TITLES = [
  "Азъ (А)", "Буки (Б)", "Веди (В)", "Глаголь (Г)", "Добро (Д)", "Есть (Е)", "Живѣтє (Ж)", "Зело (З)", "Земля (Ѕ)", "Иже (И)",
  "И (І)", "Како (К)", "Люди (Л)", "Мыслете (М)", "Наш (Н)", "Он (О)", "Покой (П)", "Рцы (Р)", "Слово (С)", "Твердо (Т)",
  "Ук (У)", "Ферт (Ф)", "Хер (Х)", "Ци (Ц)", "Червь (Ч)", "Ша (Ш)", "Ща (Щ)", "Твёрдый знак (Ъ)", "Ы", "Мягкий знак (Ь)",
  "Э", "Ю", "Я", "⊕", "∴", "∞", "Резон", "Явь", "Поле", "Точка", "Архе", "Тень", "Врата", "Лик", "Суть", "Глас", "Дыхание", "Вибрация", "Свет"
] as const;
export const AZ: readonly Az[] = AZ_TITLES.map((title, index) => ({ id: `A${index + 1}` as `A${number}`, title }));

const BUKI_DATA = [
  ["⊕", "Суперпозиция"], ["∅", "Пустота"], ["τ", "Пластичность времени"], ["Ψ", "Волновая форма"], ["C^{⊕}", "⊕‑Капитал"], ["Σ", "Сумма резонансов"],
  ["φ", "Фаза пробуждения"], ["R_f", "Резонанс с будущим"], ["∇", "Градиент"], ["I_{Я}", "Интеграция ядра"], ["⊗", "Точка кристаллизации"], ["F_s", "Поток смысла"],
  ["λ", "Длина волны"], ["A", "Амплитуда переживания"], ["∆S", "Изменение смысла"], ["Q", "Качество отклика"], ["T", "Текучесть"], ["S_f", "Структурная форма"],
  ["C_m", "Контейнер смыслов"], ["E^{⊕}", "Энтропическая энергия"], ["α", "Коэффициент соответствия"], ["k", "Плотность восприятия"], ["ω", "Частота обновления"], ["⊕(Σ)", "Суперпозиция систем"]
] as const;
export const BUKI: readonly Buka[] = BUKI_DATA.map(([symbol, title], index) => ({ id: `B${index + 1}` as `B${number}`, symbol, title }));

export const TRANSMISSIONS: readonly Transmission[] = [
  { id: "TX1", title: "Ядро", focus: "Центрация. Ноль. Сбор в присутствии." },
  { id: "TX2", title: "Орбита", focus: "Расширение поля без потери центра." },
  { id: "TX3", title: "Резонанс", focus: "Настройка на отклик среды." },
  { id: "TX4", title: "Мост", focus: "Перевод смысла в действие." },
  { id: "TX5", title: "Материализация", focus: "Фокусированное действие." },
  { id: "TX6", title: "Интеграция", focus: "Удержание результата в системе." },
  { id: "TX7", title: "Перезапуск", focus: "Снятие инерции и новый заход." }
];

export const CATALOG_VERSION = "architectonica-catalog/1.0.0";
export const CARD_IDS = new Set(CARDS.map(({ id }) => id));
export const AZ_IDS = new Set(AZ.map(({ id }) => id));
export const BUKA_IDS = new Set(BUKI.map(({ id }) => id));
export const TRANSMISSION_IDS = new Set(TRANSMISSIONS.map(({ id }) => id));

export function assertCatalogIntegrity(): void {
  const collections: [string, readonly { id: string }[], number][] = [["cards", CARDS, 96], ["az", AZ, 49], ["buki", BUKI, 24], ["transmissions", TRANSMISSIONS, 7]];
  for (const [name, values, expected] of collections) {
    if (values.length !== expected) throw new Error(`${name}: expected ${expected}, received ${values.length}`);
    if (new Set(values.map(({ id }) => id)).size !== values.length) throw new Error(`${name}: duplicate id`);
  }
}
