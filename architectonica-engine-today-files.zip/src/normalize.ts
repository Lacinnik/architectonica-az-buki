import { CONTEXTS, PLATES, type EngineInput, type Metrics, type NormalizedInput, type RawMetrics } from "./types.js";
import { AZ_IDS, BUKA_IDS, CARD_IDS, TRANSMISSION_IDS } from "./catalog.js";

export class InputValidationError extends Error {
  constructor(public readonly reasons: string[]) {
    super(reasons.join("; "));
    this.name = "InputValidationError";
  }
}

function number01(value: unknown, field: string): number {
  const parsed = typeof value === "string" ? Number(value.replace(",", ".")) : Number(value);
  if (!Number.isFinite(parsed) || parsed < 0 || parsed > 1) throw new InputValidationError([`${field} must be a number in range 0..1`]);
  return parsed;
}

export function normalizeMetrics(raw: RawMetrics): Metrics {
  const iy = raw.IY ?? raw["IЯ"];
  const errors: string[] = [];
  const read = (value: unknown, field: string): number => {
    try { return number01(value, field); } catch (error) {
      if (error instanceof InputValidationError) errors.push(...error.reasons);
      return 0;
    }
  };
  const metrics = { alpha: read(raw.alpha, "alpha"), IY: read(iy, "IY"), Cm: read(raw.Cm, "Cm"), Q: read(raw.Q, "Q"), T: read(raw.T, "T") };
  if (errors.length) throw new InputValidationError(errors);
  return metrics;
}

export function normalizeInput(input: EngineInput, makeId: () => string): NormalizedInput {
  const reasons: string[] = [];
  if (!input.subjectId?.trim()) reasons.push("subjectId is required");
  if (!input.sessionId?.trim()) reasons.push("sessionId is required");
  if (!input.intention?.trim()) reasons.push("intention is required");
  if (!PLATES.includes(input.plate)) reasons.push("plate is invalid");
  if (!CONTEXTS.includes(input.context)) reasons.push("context is invalid");
  if (input.cardId && !CARD_IDS.has(input.cardId)) reasons.push("cardId is invalid");
  if (input.azId && !AZ_IDS.has(input.azId as `A${number}`)) reasons.push("azId is invalid");
  if (input.bukaId && !BUKA_IDS.has(input.bukaId as `B${number}`)) reasons.push("bukaId is invalid");
  if (input.transmissionId && !TRANSMISSION_IDS.has(input.transmissionId as `TX${number}`)) reasons.push("transmissionId is invalid");
  if (reasons.length) throw new InputValidationError(reasons);

  return {
    ...input,
    subjectId: input.subjectId.trim(),
    sessionId: input.sessionId.trim(),
    eventId: input.eventId?.trim() || makeId(),
    intention: input.intention.trim(),
    metrics: normalizeMetrics(input.metrics)
  };
}
