import type { Metrics, Plate } from "./types.js";

type ThresholdPair = { love: Pick<Metrics, "Q" | "T" | "alpha">; measure: Pick<Metrics, "IY" | "Cm" | "alpha"> };

export const POLICY_VERSION = "architectonica-policy/1.0.0";
export const ANGELIC_THRESHOLDS = Object.freeze({ alpha: 0.75, Q: 0.75, T: 0.75 });

export const GATE_THRESHOLDS: Readonly<Record<Plate, ThresholdPair>> = Object.freeze({
  "РЕСУРС": { love: { Q: 0.5, T: 0.75, alpha: 0.5 }, measure: { IY: 0.5, Cm: 0.5, alpha: 0.5 } },
  "ВЛАСТЬ": { love: { Q: 0.75, T: 0.5, alpha: 0.75 }, measure: { IY: 0.75, Cm: 0.5, alpha: 0.75 } },
  "ОТНОШЕНИЯ": { love: { Q: 0.75, T: 0.75, alpha: 0.5 }, measure: { IY: 0.5, Cm: 0.75, alpha: 0.75 } },
  "РЕЗУЛЬТАТ": { love: { Q: 0.5, T: 0.5, alpha: 0.75 }, measure: { IY: 0.75, Cm: 0.75, alpha: 0.75 } }
});

export const POINT_TO_TRANSMISSIONS = Object.freeze({
  "Разрыв": ["TX1", "TX7"],
  "Залипание": ["TX2", "TX3"],
  "Вход": ["TX3", "TX4"],
  "Интеграция": ["TX6", "TX5"]
} as const);
