export const PLATES = ["РЕСУРС", "ВЛАСТЬ", "ОТНОШЕНИЯ", "РЕЗУЛЬТАТ"] as const;
export type Plate = (typeof PLATES)[number];

export const CONTEXTS = ["personal", "org", "public", "unknown"] as const;
export type Context = (typeof CONTEXTS)[number];
export type Impact = "draft" | "private" | "shared" | "external";
export type Phase = "point" | "architect" | "creator" | "source";
export type Position = "P1" | "P2" | "P3" | "P4";
export type PointType = "Разрыв" | "Залипание" | "Вход" | "Интеграция";
export type Geometry = "Euclid" | "Lobachevsky" | "Riemann" | "Projective" | "Supra";
export type RecommendedMode = "hold" | "observe" | "stabilize" | "continue" | "shift";

export interface Metrics {
  alpha: number;
  IY: number;
  Cm: number;
  Q: number;
  T: number;
}

export interface RawMetrics {
  alpha?: unknown;
  IY?: unknown;
  "IЯ"?: unknown;
  Cm?: unknown;
  Q?: unknown;
  T?: unknown;
}

export interface EngineInput {
  subjectId: string;
  sessionId: string;
  eventId?: string;
  intention: string;
  plate: Plate;
  cardId?: string;
  azId?: string;
  bukaId?: string;
  transmissionId?: string;
  pointType?: PointType;
  geometry?: Geometry;
  position?: Position;
  phase?: Phase;
  induction?: string;
  inversion?: string;
  objectLabel?: string;
  imageLabel?: string;
  metrics: RawMetrics;
  context: Context;
  impact: Impact;
  owner?: string | null;
  explicitAuthorization?: boolean;
  risk?: "low" | "medium" | "high" | "critical";
  metadata?: Record<string, unknown>;
  sharedField?: import("./collective.js").SharedField;
}

export interface NormalizedInput extends Omit<EngineInput, "metrics" | "eventId"> {
  eventId: string;
  metrics: Metrics;
}

export type GateName = "validation" | "negative" | "governance" | "angelic" | "love" | "measure" | "collective" | "ok";
export interface GateResult {
  gate: GateName;
  pass: boolean;
  reason: string;
  actual?: Partial<Metrics>;
  thresholds?: Partial<Metrics>;
}

export interface EngineDecision {
  decisionId: string;
  status: "invalid" | "halted" | "blocked" | "allowed";
  allow: boolean;
  gate: GateName;
  reasons: string[];
  warnings: string[];
  normalizedInput?: NormalizedInput;
  gateResults: GateResult[];
  resolvedState?: import("./state.js").ResolvedState;
  chronos?: import("./chronos.js").ChronosAnalysis;
  collective?: import("./collective.js").CollectiveDecision;
  recommendedTransmission?: string;
  recommendedMode?: RecommendedMode;
  policyVersion: string;
  engineVersion: string;
  catalogVersion: string;
  storeSchemaVersion: number;
  createdAt: string;
}

export interface EngineOutcome {
  outcomeId: string;
  sessionId: string;
  eventId: string;
  decisionId: string;
  successScore?: number;
  realizedBranch?: boolean;
  notes?: string;
  createdAt: string;
  subjectId?: string;
  predictedMode?: RecommendedMode;
}
