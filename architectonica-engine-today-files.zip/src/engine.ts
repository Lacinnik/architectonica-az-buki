import { angelicGate, governanceGate, loveGate, measureGate, negativeGate } from "./gates.js";
import { InputValidationError, normalizeInput } from "./normalize.js";
import { POINT_TO_TRANSMISSIONS, POLICY_VERSION } from "./policy.js";
import { MemoryStore, type EngineStore } from "./store.js";
import type { EngineDecision, EngineInput, EngineOutcome, GateResult, NormalizedInput, RecommendedMode } from "./types.js";
import { DeterministicChronos, type ChronosAnalysis, type ChronosPort } from "./chronos.js";
import { ProductionChronos } from "./chronos-production.js";
import { DeterministicCreator, type CreatorPort, type MaterializationArtifact } from "./creator.js";
import { resolveState, type ResolvedState } from "./state.js";
import { CollectiveEngine, type CollectiveDecision } from "./collective.js";
import { VERSION_MANIFEST } from "./version.js";

export interface EngineOptions { store?: EngineStore; chronos?: ChronosPort; creator?: CreatorPort; collective?: CollectiveEngine; makeId?: () => string; now?: () => Date; }
export interface EngineExecution { decision: EngineDecision; artifact?: MaterializationArtifact; }

export class ArchitectonicaEngine {
  readonly store: EngineStore;
  private readonly makeId: () => string;
  private readonly now: () => Date;
  private readonly chronos: ChronosPort;
  private readonly creator: CreatorPort;
  private readonly collective: CollectiveEngine;
  private chronosHydrated = false;

  constructor(options: EngineOptions = {}) {
    this.store = options.store ?? new MemoryStore();
    this.makeId = options.makeId ?? (() => globalThis.crypto.randomUUID());
    this.now = options.now ?? (() => new Date());
    this.chronos = options.chronos ?? new ProductionChronos();
    this.creator = options.creator ?? new DeterministicCreator();
    this.collective = options.collective ?? new CollectiveEngine();
  }

  async execute(raw: EngineInput): Promise<EngineExecution> {
    const decision = await this.evaluate(raw);
    if (!decision.allow) return { decision };
    const artifact = await this.creator.materialize(decision, this.makeId, this.now);
    return { decision, artifact };
  }

  async evaluate(raw: EngineInput): Promise<EngineDecision> {
    let input: NormalizedInput;
    try {
      input = normalizeInput(raw, this.makeId);
    } catch (error) {
      const reasons = error instanceof InputValidationError ? error.reasons : ["unexpected validation error"];
      return this.persistDecision({ decisionId: this.makeId(), status: "invalid", allow: false, gate: "validation", reasons, warnings: [], gateResults: [{ gate: "validation", pass: false, reason: reasons.join("; ") }], policyVersion: POLICY_VERSION, engineVersion: VERSION_MANIFEST.engine, catalogVersion: VERSION_MANIFEST.catalog, storeSchemaVersion: VERSION_MANIFEST.storeSchema, createdAt: this.now().toISOString() });
    }

    const history = await this.store.listEvents(input.sessionId);
    if (!this.chronosHydrated) {
      await this.chronos.hydrateOutcomes?.(await this.store.listOutcomes(input.sessionId));
      this.chronosHydrated = true;
    }
    const chronos = await this.chronos.analyze(input, history);
    const resolvedState = resolveState(input);
    await this.store.appendEvent(input);
    const gates: GateResult[] = [];
    for (const run of [negativeGate, governanceGate, angelicGate, loveGate, measureGate]) {
      const gate = run(input);
      gates.push(gate);
      if (!gate.pass) {
        const status = gate.gate === "negative" || gate.gate === "governance" ? "halted" : "blocked";
        return this.persistDecision(this.makeDecision(input, status, false, gate.gate, [gate.reason], gates, chronos, resolvedState));
      }
    }
    let collectiveDecision: CollectiveDecision | undefined;
    if (input.sharedField) {
      collectiveDecision = this.collective.evaluate(input.sharedField);
      const collectiveGate: GateResult = { gate: "collective", pass: collectiveDecision.allow, reason: collectiveDecision.reason };
      gates.push(collectiveGate);
      if (!collectiveDecision.allow) return this.persistDecision(this.makeDecision(input, "blocked", false, "collective", [collectiveDecision.reason], gates, chronos, resolvedState, undefined, collectiveDecision));
    }
    const transmission = input.transmissionId ?? (input.pointType ? POINT_TO_TRANSMISSIONS[input.pointType][0] : undefined);
    return this.persistDecision(this.makeDecision(input, "allowed", true, "ok", [], gates, chronos, resolvedState, transmission, collectiveDecision));
  }

  async recordOutcome(input: Omit<EngineOutcome, "outcomeId" | "createdAt"> & Partial<Pick<EngineOutcome, "outcomeId" | "createdAt">>): Promise<EngineOutcome> {
    const decision = await this.store.getDecision(input.decisionId);
    if (!decision) throw new Error("decisionId does not exist");
    if (decision.normalizedInput?.eventId !== input.eventId || decision.normalizedInput.sessionId !== input.sessionId) throw new Error("outcome does not match decision event/session");
    if (input.successScore !== undefined && (!Number.isFinite(input.successScore) || input.successScore < 0 || input.successScore > 1)) throw new Error("successScore must be in range 0..1");
    const outcome: EngineOutcome = { ...input, subjectId: decision.normalizedInput.subjectId, predictedMode: decision.recommendedMode ?? "observe", outcomeId: input.outcomeId ?? this.makeId(), createdAt: input.createdAt ?? this.now().toISOString() };
    await this.store.appendOutcome(outcome);
    await this.chronos.recordOutcome?.(outcome);
    return outcome;
  }

  private makeDecision(input: NormalizedInput, status: EngineDecision["status"], allow: boolean, gate: EngineDecision["gate"], reasons: string[], gateResults: GateResult[], chronos: ChronosAnalysis, resolvedState: ResolvedState, recommendedTransmission?: string, collective?: CollectiveDecision): EngineDecision {
    const pointMode: RecommendedMode = input.pointType === "Залипание" ? "shift" : input.pointType === "Разрыв" ? "stabilize" : chronos.recommendedMode;
    return { decisionId: this.makeId(), status, allow, gate, reasons, warnings: [], normalizedInput: input, gateResults, chronos, resolvedState, ...(collective ? { collective } : {}), ...(recommendedTransmission ? { recommendedTransmission } : {}), recommendedMode: pointMode, policyVersion: POLICY_VERSION, engineVersion: VERSION_MANIFEST.engine, catalogVersion: VERSION_MANIFEST.catalog, storeSchemaVersion: VERSION_MANIFEST.storeSchema, createdAt: this.now().toISOString() };
  }

  private async persistDecision(decision: EngineDecision): Promise<EngineDecision> {
    await this.store.appendDecision(decision);
    return decision;
  }
}
