import { ChronosAI, type ChronosEventInput, type ChronosOutcomeRecord } from "../chronos_ai_module.js";
import type { ChronosAnalysis, ChronosPort } from "./chronos.js";
import type { EngineOutcome, NormalizedInput } from "./types.js";

const toEvent = (event: NormalizedInput): ChronosEventInput => ({
  ...(typeof event.metadata?.["legacyTimestamp"] === "string" ? { ts: event.metadata["legacyTimestamp"] } : {}),
  userId: event.subjectId,
  plate: event.plate,
  azId: event.azId ?? null,
  bukaId: event.bukaId ?? null,
  txId: event.transmissionId ?? null,
  pointType: event.pointType ?? null,
  geometry: event.geometry ?? null,
  note: event.intention,
  ...(event.induction !== undefined ? { induction: event.induction } : {}),
  ...(event.inversion !== undefined ? { inversion: event.inversion } : {}),
  ...(event.objectLabel !== undefined ? { objectLabel: event.objectLabel } : {}),
  ...(event.imageLabel !== undefined ? { imageLabel: event.imageLabel } : {}),
  metrics: event.metrics,
  ...(event.metadata !== undefined ? { metadata: event.metadata } : {}),
});

export class ProductionChronos implements ChronosPort {
  private readonly core: ChronosAI;
  private readonly hydratedSubjects = new Set<string>();

  constructor(core = new ChronosAI()) { this.core = core; }

  async analyze(event: NormalizedInput, history: readonly NormalizedInput[]): Promise<ChronosAnalysis> {
    if (!this.hydratedSubjects.has(event.subjectId)) {
      for (const previous of history) await this.core.analyze(toEvent(previous));
      this.hydratedSubjects.add(event.subjectId);
    }
    const result = await this.core.analyze(toEvent(event));
    const loop = this.core.detectLoop(event.subjectId);
    const profile = this.core.getMemory(event.subjectId).profile;
    return {
      trajectoryType: result.trajectoryType,
      dominantArrow: result.dominantArrow,
      branchProbability: result.branchProbability,
      shiftProbability: result.shiftProbability,
      continuationProbability: result.continuationProbability,
      recommendedMode: result.recommendedMode,
      loop: loop.loopKind,
      reasons: [...result.reasons, ...loop.reasons.map((reason) => `loop:${reason}`)],
      state: { ...result.state },
      profile: { ...profile },
    };
  }

  async hydrateOutcomes(outcomes: readonly EngineOutcome[]): Promise<void> {
    for (const outcome of outcomes) await this.core.recordOutcome(this.toOutcome(outcome));
  }

  async recordOutcome(outcome: EngineOutcome): Promise<void> { await this.core.recordOutcome(this.toOutcome(outcome)); }

  private toOutcome(outcome: EngineOutcome): ChronosOutcomeRecord {
    return {
      ts: outcome.createdAt,
      ...(outcome.subjectId ? { userId: outcome.subjectId } : {}),
      predictedMode: outcome.predictedMode ?? "observe",
      chosenMode: outcome.predictedMode ?? "observe",
      realizedBranch: outcome.realizedBranch ?? null,
      successScore: outcome.successScore ?? null,
      ...(outcome.notes !== undefined ? { notes: outcome.notes } : {}),
    };
  }
}
