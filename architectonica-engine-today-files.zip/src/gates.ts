import { ANGELIC_THRESHOLDS, GATE_THRESHOLDS } from "./policy.js";
import type { GateResult, Metrics, NormalizedInput } from "./types.js";

const meets = (metrics: Metrics, thresholds: Partial<Metrics>): boolean =>
  Object.entries(thresholds).every(([key, threshold]) => metrics[key as keyof Metrics] >= (threshold ?? 0));

function result(gate: GateResult["gate"], pass: boolean, reason: string, input: NormalizedInput, thresholds?: Partial<Metrics>): GateResult {
  return { gate, pass, reason, actual: input.metrics, ...(thresholds ? { thresholds } : {}) };
}

export function negativeGate(input: NormalizedInput): GateResult {
  const blocked = input.risk === "critical" || input.metadata?.["halt"] === true;
  return result("negative", !blocked, blocked ? "critical risk or explicit halt" : "", input);
}

export function governanceGate(input: NormalizedInput): GateResult {
  if (input.context === "unknown") return result("governance", false, "unknown context: default deny", input);
  if (input.context === "public" && input.explicitAuthorization !== true) return result("governance", false, "public context requires explicit authorization", input);
  if ((input.impact === "shared" || input.impact === "external") && !input.owner) return result("governance", false, "owner is required for shared or external impact", input);
  return result("governance", true, "", input);
}

export function angelicGate(input: NormalizedInput): GateResult {
  const pass = meets(input.metrics, ANGELIC_THRESHOLDS);
  return result("angelic", pass, pass ? "" : "Need α≥0.75, Q≥0.75, T≥0.75", input, ANGELIC_THRESHOLDS);
}

export function loveGate(input: NormalizedInput): GateResult {
  const thresholds = GATE_THRESHOLDS[input.plate].love;
  const pass = meets(input.metrics, thresholds);
  return result("love", pass, pass ? "" : `Love gate failed for ${input.plate}`, input, thresholds);
}

export function measureGate(input: NormalizedInput): GateResult {
  const thresholds = GATE_THRESHOLDS[input.plate].measure;
  const pass = meets(input.metrics, thresholds);
  return result("measure", pass, pass ? "" : `Measure gate failed for ${input.plate}`, input, thresholds);
}
