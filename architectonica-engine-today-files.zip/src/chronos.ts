import type { EngineOutcome, NormalizedInput, RecommendedMode } from "./types.js";

export type TrajectoryType = "T_self" | "T_social" | "hybrid";
export interface ChronosAnalysis {
  trajectoryType: TrajectoryType;
  branchProbability: number;
  shiftProbability: number;
  continuationProbability: number;
  recommendedMode: RecommendedMode;
  loop: "none" | "stagnation" | "repetition" | "oscillation";
  reasons: string[];
  dominantArrow?: "I_now->E_future" | "E_past->I_future" | "balanced";
  state?: Record<string, number>;
  profile?: Record<string, unknown>;
}

export interface ChronosPort {
  analyze(event: NormalizedInput, history: readonly NormalizedInput[]): Promise<ChronosAnalysis>;
  recordOutcome?(outcome: EngineOutcome): Promise<void>;
  hydrateOutcomes?(outcomes: readonly EngineOutcome[]): Promise<void>;
}

const round = (value: number) => Math.round(Math.max(0, Math.min(1, value)) * 1000) / 1000;
const textSignal = (value?: string): number => Math.min(1, (value?.trim().length ?? 0) / 160);

export class DeterministicChronos implements ChronosPort {
  private feedbackBias = 0;
  private feedbackScores: number[] = [];

  async hydrateOutcomes(outcomes: readonly EngineOutcome[]): Promise<void> {
    this.feedbackScores = outcomes.map(({ successScore }) => successScore).filter((score): score is number => typeof score === "number");
    this.recalculateBias();
  }

  async recordOutcome(outcome: EngineOutcome): Promise<void> {
    if (outcome.successScore === undefined) return;
    this.feedbackScores.push(outcome.successScore);
    this.recalculateBias();
  }

  private recalculateBias(): void {
    const recent = this.feedbackScores.slice(-12);
    this.feedbackBias = recent.length ? round(recent.reduce((sum, score) => sum + score - 0.5, 0) / recent.length * 0.2) : 0;
  }

  async analyze(event: NormalizedInput, history: readonly NormalizedInput[]): Promise<ChronosAnalysis> {
    const self = textSignal(event.induction) + event.metrics.IY;
    const social = textSignal(event.inversion) + event.metrics.Q;
    const delta = self - social;
    const trajectoryType: TrajectoryType = Math.abs(delta) < 0.2 ? "hybrid" : delta > 0 ? "T_self" : "T_social";
    const recent = [...history, event].slice(-4);
    const repetition = recent.length >= 3 && recent.every((item) => item.pointType === recent[0]?.pointType && item.transmissionId === recent[0]?.transmissionId);
    const stagnation = recent.length >= 3 && recent.every((item) => item.metrics.T < 0.5);
    const alternates = recent.length === 4 && recent[0]?.plate === recent[2]?.plate && recent[1]?.plate === recent[3]?.plate && recent[0]?.plate !== recent[1]?.plate;
    const loop = stagnation ? "stagnation" : repetition ? "repetition" : alternates ? "oscillation" : "none";
    const coherence = (event.metrics.alpha + event.metrics.Q + event.metrics.T) / 3;
    const shiftProbability = round((1 - coherence) * 0.65 + (loop === "none" ? 0 : 0.35));
    const continuationProbability = round(coherence * (loop === "none" ? 1 : 0.55) + this.feedbackBias);
    const branchProbability = round(0.5 * shiftProbability + 0.5 * Math.abs(delta) / 2);
    const recommendedMode: RecommendedMode = loop !== "none" ? "shift" : coherence < 0.5 ? "stabilize" : branchProbability > 0.55 ? "observe" : "continue";
    const reasons = [`trajectory=${trajectoryType}`, `coherence=${round(coherence)}`];
    if (loop !== "none") reasons.push(`loop=${loop}`);
    return { trajectoryType, branchProbability, shiftProbability, continuationProbability, recommendedMode, loop, reasons };
  }
}
