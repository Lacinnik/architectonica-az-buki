import type { Metrics } from "./types.js";

export interface TrustLink { from: string; to: string; object: string; image?: string; metrics?: Partial<Metrics>; timestamp?: string; }
export interface SharedObject { id?: string; label: string; metrics: Metrics; createdBy: string; timestamp?: string; }
export interface SharedField { id: string; subjectIds: string[]; trustLinks: TrustLink[]; sharedObjects: SharedObject[]; activePhase?: string; }
export type CollectiveGate = "validation" | "trust" | "metrics" | "sync" | "ok";
export interface CollectiveDecision {
  allow: boolean;
  gate: CollectiveGate;
  reason: string;
  synthesisReady: boolean;
  averageMetrics: Metrics;
  missingTrustLinks: { from: string; to: string }[];
  subjects: string[];
  sharedId: string;
}

export interface CollectivePolicy { alpha: number; Q: number; T: number; IY: number; Cm: number; requireBidirectionalTrust: boolean; }
export const DEFAULT_COLLECTIVE_POLICY: Readonly<CollectivePolicy> = Object.freeze({ alpha: 0.75, Q: 0.75, T: 0.75, IY: 0.5, Cm: 0.5, requireBidirectionalTrust: true });

const zeroMetrics = (): Metrics => ({ alpha: 0, Q: 0, T: 0, IY: 0, Cm: 0 });

export class CollectiveEngine {
  constructor(private readonly policy: CollectivePolicy = DEFAULT_COLLECTIVE_POLICY) {}

  evaluate(field: SharedField): CollectiveDecision {
    const subjects = [...new Set(field.subjectIds.filter(Boolean))];
    const base = { averageMetrics: this.average(field.sharedObjects), subjects, sharedId: field.id };
    if (!field.id || subjects.length < 2) return { ...base, allow: false, gate: "validation", reason: "collective field requires id and at least two unique subjects", synthesisReady: false, missingTrustLinks: [] };
    const missingTrustLinks = this.missingLinks(subjects, field.trustLinks);
    if (missingTrustLinks.length) return { ...base, allow: false, gate: "trust", reason: "required trust links are missing", synthesisReady: false, missingTrustLinks };
    if (!field.sharedObjects.length || subjects.some((subject) => !field.sharedObjects.some((object) => object.createdBy === subject))) return { ...base, allow: false, gate: "sync", reason: "every subject must contribute a shared object", synthesisReady: false, missingTrustLinks: [] };
    const m = base.averageMetrics;
    const pass = m.alpha >= this.policy.alpha && m.Q >= this.policy.Q && m.T >= this.policy.T && m.IY >= this.policy.IY && m.Cm >= this.policy.Cm;
    if (!pass) return { ...base, allow: false, gate: "metrics", reason: "collective conductance is below policy thresholds", synthesisReady: false, missingTrustLinks: [] };
    return { ...base, allow: true, gate: "ok", reason: "", synthesisReady: true, missingTrustLinks: [] };
  }

  private missingLinks(subjects: string[], links: TrustLink[]): { from: string; to: string }[] {
    const pairs: { from: string; to: string }[] = [];
    for (const from of subjects) for (const to of subjects) {
      if (from === to) continue;
      if (!this.policy.requireBidirectionalTrust && from > to) continue;
      const exists = links.some((link) => (link.from === from && link.to === to) || (!this.policy.requireBidirectionalTrust && link.from === to && link.to === from));
      if (!exists) pairs.push({ from, to });
    }
    return pairs;
  }

  private average(objects: SharedObject[]): Metrics {
    if (!objects.length) return zeroMetrics();
    const keys: (keyof Metrics)[] = ["alpha", "Q", "T", "IY", "Cm"];
    return Object.fromEntries(keys.map((key) => [key, objects.reduce((sum, object) => sum + object.metrics[key], 0) / objects.length])) as unknown as Metrics;
  }
}
