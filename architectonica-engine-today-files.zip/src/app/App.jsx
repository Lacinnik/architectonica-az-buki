import React, { useMemo, useState } from "react";
import GDEYAAppTabs from "../../gdeya_react_ядро_субъекта.jsx";
import { ArchitectonicaEngine } from "../engine.ts";
import { GdeyaEngineController } from "../adapters/gdeya-controller.ts";
import { LocalStorageStore } from "../store.ts";

const SESSION_KEY = "architectonica_active_session_v1";
const SESSION_REGISTRY_KEY = "architectonica_sessions_v1";
const randomId = (prefix) => `${prefix}-${globalThis.crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2)}`;

function loadSession() {
  try { return JSON.parse(localStorage.getItem(SESSION_KEY) || "null"); } catch { return null; }
}

function loadSessions() {
  try {
    const value = JSON.parse(localStorage.getItem(SESSION_REGISTRY_KEY) || "[]");
    return Array.isArray(value) ? value : [];
  } catch { return []; }
}

function saveSessions(sessions) { localStorage.setItem(SESSION_REGISTRY_KEY, JSON.stringify(sessions)); }

function SessionGate({ onStart, sessions, onResume }) {
  const [name, setName] = useState("");
  const [subject, setSubject] = useState("");
  const [context, setContext] = useState("personal");
  const [impact, setImpact] = useState("draft");
  const [explicitAuthorization, setExplicitAuthorization] = useState(false);
  const submit = (event) => {
    event.preventDefault();
    if (!name.trim() || !subject.trim()) return;
    onStart({ name: name.trim(), subjectName: subject.trim(), subjectId: randomId("subject"), sessionId: randomId("session"), context, impact, explicitAuthorization, createdAt: new Date().toISOString(), lastOpenedAt: new Date().toISOString() });
  };
  return (
    <main className="session-shell">
      <section className="session-card">
        <div className="sigil">⊕</div>
        <p className="eyebrow">ARCHITECTONICA ENGINE</p>
        <h1>Вход в сессию</h1>
        <p className="lead">Создай рабочий контур субъекта. Все переходы будут проверяться Engine и сохраняться локально.</p>
        <form onSubmit={submit}>
          <label>Субъект<input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Имя или обозначение" /></label>
          <label>Сессия<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Задача или цикл" /></label>
          <div className="form-grid">
            <label>Контекст<select value={context} onChange={(e) => setContext(e.target.value)}><option value="personal">Личный</option><option value="org">Организационный</option><option value="public">Публичный</option></select></label>
            <label>Воздействие<select value={impact} onChange={(e) => setImpact(e.target.value)}><option value="draft">Черновик</option><option value="private">Личное</option><option value="shared">Совместное</option><option value="external">Внешнее</option></select></label>
          </div>
          {context === "public" && (
            <label className="authorization"><input type="checkbox" checked={explicitAuthorization} onChange={(e) => setExplicitAuthorization(e.target.checked)} /><span>Подтверждаю полномочия на действие в публичном контексте</span></label>
          )}
          <button className="primary" type="submit">Открыть контур</button>
        </form>
        {!!sessions.length && (
          <div className="session-history">
            <p className="eyebrow">СОХРАНЁННЫЕ КОНТУРЫ</p>
            {sessions.map((session) => (
              <button key={session.sessionId} className="session-row" onClick={() => onResume(session)}>
                <span><strong>{session.name}</strong><small>{session.subjectName} · {session.context}</small></span>
                <time>{new Date(session.lastOpenedAt || session.createdAt).toLocaleDateString()}</time>
              </button>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}

function Workspace({ session, onClose }) {
  const [lastDecision, setLastDecision] = useState(null);
  const controller = useMemo(() => {
    const store = new LocalStorageStore(window.localStorage, `architectonica_engine_v1:${session.sessionId}`);
    const engine = new ArchitectonicaEngine({ store });
    return new GdeyaEngineController(engine, { subjectId: session.subjectId, sessionId: session.sessionId, context: session.context, impact: session.impact, owner: session.subjectId, explicitAuthorization: session.explicitAuthorization });
  }, [session]);
  return (
    <div className="workspace">
      <aside className="session-bar">
        <div><span className={`status-dot ${lastDecision && !lastDecision.allow ? "blocked" : ""}`} /><strong>{session.name}</strong><small>{session.subjectName} · {session.context} · {session.impact}</small></div>
        {lastDecision && <div className={`decision-badge ${lastDecision.allow ? "allowed" : "denied"}`}><strong>{lastDecision.allow ? "Допуск" : "Стоп"}</strong><small>{lastDecision.gate} · {lastDecision.resolvedState?.manifestation ?? "—"}</small></div>}
        <button onClick={onClose}>Завершить сессию</button>
      </aside>
      <GDEYAAppTabs engineController={controller} onEngineDecision={setLastDecision} />
    </div>
  );
}

export default function App() {
  const [session, setSession] = useState(loadSession);
  const [sessions, setSessions] = useState(loadSessions);
  const start = (next) => {
    const updated = [next, ...sessions.filter((item) => item.sessionId !== next.sessionId)];
    saveSessions(updated); setSessions(updated);
    localStorage.setItem(SESSION_KEY, JSON.stringify(next)); setSession(next);
  };
  const resume = (existing) => start({ ...existing, lastOpenedAt: new Date().toISOString() });
  const close = () => { localStorage.removeItem(SESSION_KEY); setSession(null); };
  return session ? <Workspace session={session} onClose={close} /> : <SessionGate onStart={start} sessions={sessions} onResume={resume} />;
}
