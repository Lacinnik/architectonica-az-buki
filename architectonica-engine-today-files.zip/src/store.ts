import type { EngineDecision, EngineOutcome, NormalizedInput } from "./types.js";
import { ENGINE_VERSION, STORE_SCHEMA_VERSION } from "./version.js";

export interface EngineStore {
  hasEvent(eventId: string): Promise<boolean>;
  appendEvent(event: NormalizedInput): Promise<void>;
  appendDecision(decision: EngineDecision): Promise<void>;
  appendOutcome(outcome: EngineOutcome): Promise<void>;
  listEvents(sessionId: string): Promise<NormalizedInput[]>;
  getDecision(decisionId: string): Promise<EngineDecision | null>;
  listOutcomes(sessionId: string): Promise<EngineOutcome[]>;
  listDecisions(sessionId: string): Promise<EngineDecision[]>;
}

export class MemoryStore implements EngineStore {
  readonly events: NormalizedInput[] = [];
  readonly decisions: EngineDecision[] = [];
  readonly outcomes: EngineOutcome[] = [];
  async hasEvent(eventId: string): Promise<boolean> { return this.events.some((event) => event.eventId === eventId); }
  async appendEvent(event: NormalizedInput): Promise<void> { if (!(await this.hasEvent(event.eventId))) this.events.push(event); }
  async appendDecision(decision: EngineDecision): Promise<void> { this.decisions.push(decision); }
  async appendOutcome(outcome: EngineOutcome): Promise<void> { this.outcomes.push(outcome); }
  async listEvents(sessionId: string): Promise<NormalizedInput[]> { return this.events.filter((event) => event.sessionId === sessionId); }
  async getDecision(decisionId: string): Promise<EngineDecision | null> { return this.decisions.find((decision) => decision.decisionId === decisionId) ?? null; }
  async listOutcomes(sessionId: string): Promise<EngineOutcome[]> { return this.outcomes.filter((outcome) => outcome.sessionId === sessionId); }
  async listDecisions(sessionId: string): Promise<EngineDecision[]> { return this.decisions.filter((decision) => decision.normalizedInput?.sessionId === sessionId); }
}

export interface StoreState {
  schemaVersion: typeof STORE_SCHEMA_VERSION;
  engineVersion: string;
  createdAt: string;
  updatedAt: string;
  events: NormalizedInput[];
  decisions: EngineDecision[];
  outcomes: EngineOutcome[];
}
export const emptyState = (now = new Date().toISOString()): StoreState => ({ schemaVersion: STORE_SCHEMA_VERSION, engineVersion: ENGINE_VERSION, createdAt: now, updatedAt: now, events: [], decisions: [], outcomes: [] });

export function migrateStoreState(value: unknown, now = new Date().toISOString()): StoreState {
  if (!value || typeof value !== "object") throw new Error("corrupt Architectonica store");
  const raw = value as Record<string, unknown>;
  const events = Array.isArray(raw.events) ? raw.events as NormalizedInput[] : [];
  const decisions = Array.isArray(raw.decisions) ? raw.decisions as EngineDecision[] : [];
  const outcomes = Array.isArray(raw.outcomes) ? raw.outcomes as EngineOutcome[] : [];
  const schema = Number(raw.schemaVersion ?? 0);
  if (schema > STORE_SCHEMA_VERSION) throw new Error(`store schema ${schema} is newer than supported ${STORE_SCHEMA_VERSION}`);
  if (![0, 1, 2].includes(schema)) throw new Error(`unsupported Architectonica store schema ${schema}`);
  const createdAt = typeof raw.createdAt === "string" ? raw.createdAt : now;
  return { schemaVersion: STORE_SCHEMA_VERSION, engineVersion: ENGINE_VERSION, createdAt, updatedAt: now, events, decisions, outcomes };
}

export abstract class PersistentStore implements EngineStore {
  protected abstract readState(): Promise<StoreState>;
  protected abstract writeState(state: StoreState): Promise<void>;

  async hasEvent(eventId: string): Promise<boolean> { return (await this.readState()).events.some((event) => event.eventId === eventId); }
  async appendEvent(event: NormalizedInput): Promise<void> {
    const state = await this.readState();
    if (!state.events.some((item) => item.eventId === event.eventId)) { state.events.push(event); state.updatedAt = new Date().toISOString(); await this.writeState(state); }
  }
  async appendDecision(decision: EngineDecision): Promise<void> { const state = await this.readState(); state.decisions.push(decision); state.updatedAt = new Date().toISOString(); await this.writeState(state); }
  async appendOutcome(outcome: EngineOutcome): Promise<void> { const state = await this.readState(); state.outcomes.push(outcome); state.updatedAt = new Date().toISOString(); await this.writeState(state); }
  async listEvents(sessionId: string): Promise<NormalizedInput[]> { return (await this.readState()).events.filter((event) => event.sessionId === sessionId); }
  async getDecision(decisionId: string): Promise<EngineDecision | null> { return (await this.readState()).decisions.find((decision) => decision.decisionId === decisionId) ?? null; }
  async listOutcomes(sessionId: string): Promise<EngineOutcome[]> { return (await this.readState()).outcomes.filter((outcome) => outcome.sessionId === sessionId); }
  async listDecisions(sessionId: string): Promise<EngineDecision[]> { return (await this.readState()).decisions.filter((decision) => decision.normalizedInput?.sessionId === sessionId); }
}

export interface StorageLike { getItem(key: string): string | null; setItem(key: string, value: string): void; }

export class LocalStorageStore extends PersistentStore {
  constructor(private readonly storage: StorageLike, private readonly key = "architectonica_engine_v1") { super(); }
  protected async readState(): Promise<StoreState> {
    const raw = this.storage.getItem(this.key);
    if (!raw) return emptyState();
    return migrateStoreState(JSON.parse(raw));
  }
  protected async writeState(state: StoreState): Promise<void> { this.storage.setItem(this.key, JSON.stringify(state)); }
}
