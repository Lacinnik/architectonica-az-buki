import type { EngineDecision } from "../types.js";
import type { EngineExecution, ArchitectonicaEngine } from "../engine.js";
import { gdeyaEntryToEngineInput, parseGdeyaDiaryJson, type GdeyaAdapterOptions, type GdeyaDiaryEntry } from "./gdeya.js";
import { VERSION_MANIFEST } from "../version.js";

export interface DiaryImportResult { total: number; allowed: number; denied: number; invalid: number; decisions: EngineDecision[]; }
export interface SubjectMemorySnapshot {
  sessionId: string;
  generatedAt: string;
  versions: typeof VERSION_MANIFEST;
  counts: { events: number; decisions: number; outcomes: number; allowed: number; denied: number };
  averageMetrics: { alpha: number; IY: number; Cm: number; Q: number; T: number };
  manifestations: Record<string, number>;
  transmissions: Record<string, { decisions: number; outcomes: number; averageSuccess: number | null }>;
  events: Awaited<ReturnType<ArchitectonicaEngine["store"]["listEvents"]>>;
  decisions: EngineDecision[];
  outcomes: Awaited<ReturnType<ArchitectonicaEngine["store"]["listOutcomes"]>>;
}

export class GdeyaEngineController {
  constructor(private readonly engine: ArchitectonicaEngine, private readonly options: GdeyaAdapterOptions) {}

  async evaluateEntry(entry: GdeyaDiaryEntry, eventId?: string): Promise<EngineDecision> {
    const input = gdeyaEntryToEngineInput(entry, this.options);
    if (eventId) input.eventId = eventId;
    return this.engine.evaluate(input);
  }

  async executeEntry(entry: GdeyaDiaryEntry, eventId?: string): Promise<EngineExecution> {
    const input = gdeyaEntryToEngineInput(entry, this.options);
    if (eventId) input.eventId = eventId;
    return this.engine.execute(input);
  }

  async importDiary(entries: readonly GdeyaDiaryEntry[]): Promise<DiaryImportResult> {
    const decisions: EngineDecision[] = [];
    for (let index = 0; index < entries.length; index += 1) {
      const entry = entries[index]!;
      const timestamp = (entry.ts ?? "no-ts").replace(/\s+/g, "_");
      const eventId = `gdeya:${this.options.sessionId}:${index}:${timestamp}:${entry.card?.id ?? "no-card"}`;
      decisions.push(await this.evaluateEntry(entry, eventId));
    }
    return { total: decisions.length, allowed: decisions.filter(({ allow }) => allow).length, denied: decisions.filter(({ status }) => status === "blocked" || status === "halted").length, invalid: decisions.filter(({ status }) => status === "invalid").length, decisions };
  }

  async importJson(json: string): Promise<DiaryImportResult> { return this.importDiary(parseGdeyaDiaryJson(json)); }

  async recordOutcome(decision: EngineDecision, successScore: number, notes = "") {
    if (!decision.normalizedInput) throw new Error("decision has no normalized input");
    return this.engine.recordOutcome({
      sessionId: decision.normalizedInput.sessionId,
      eventId: decision.normalizedInput.eventId,
      decisionId: decision.decisionId,
      successScore,
      ...(notes.trim() ? { notes: notes.trim() } : {}),
    });
  }

  async getMemorySnapshot(): Promise<SubjectMemorySnapshot> {
    const sessionId = this.options.sessionId;
    const [events, decisions, outcomes] = await Promise.all([this.engine.store.listEvents(sessionId), this.engine.store.listDecisions(sessionId), this.engine.store.listOutcomes(sessionId)]);
    const metricKeys = ["alpha", "IY", "Cm", "Q", "T"] as const;
    const averageMetrics = Object.fromEntries(metricKeys.map((key) => [key, events.length ? Math.round(events.reduce((sum, event) => sum + event.metrics[key], 0) / events.length * 1000) / 1000 : 0])) as SubjectMemorySnapshot["averageMetrics"];
    const manifestations: Record<string, number> = {};
    const transmissions: SubjectMemorySnapshot["transmissions"] = {};
    for (const decision of decisions) {
      const manifestation = decision.resolvedState?.manifestation ?? "unknown";
      manifestations[manifestation] = (manifestations[manifestation] ?? 0) + 1;
      const tx = decision.recommendedTransmission ?? "none";
      transmissions[tx] ??= { decisions: 0, outcomes: 0, averageSuccess: null };
      transmissions[tx].decisions += 1;
      const related = outcomes.filter((outcome) => outcome.decisionId === decision.decisionId && outcome.successScore !== undefined);
      if (related.length) {
        transmissions[tx].outcomes += related.length;
        const scores = outcomes.filter((outcome) => decisions.some((item) => item.decisionId === outcome.decisionId && (item.recommendedTransmission ?? "none") === tx)).map(({ successScore }) => successScore).filter((score): score is number => typeof score === "number");
        transmissions[tx].averageSuccess = scores.length ? Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length * 1000) / 1000 : null;
      }
    }
    return { sessionId, generatedAt: new Date().toISOString(), versions: VERSION_MANIFEST, counts: { events: events.length, decisions: decisions.length, outcomes: outcomes.length, allowed: decisions.filter(({ allow }) => allow).length, denied: decisions.filter(({ allow }) => !allow).length }, averageMetrics, manifestations, transmissions, events, decisions, outcomes };
  }
}
