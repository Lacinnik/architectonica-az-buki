import { CONTEXTS, type Context, type EngineInput, type Geometry, type Impact, type Plate, type PointType, type Position, type RawMetrics } from "../types.js";

interface LegacyRef { id?: string; title?: string; symbol?: string; }
export interface GdeyaDiaryEntry {
  ts?: string;
  plate?: string;
  card?: { id?: string; process?: string; roman?: string; arabic?: number };
  states?: unknown[];
  az?: LegacyRef | null;
  buka?: LegacyRef | null;
  tx?: LegacyRef | null;
  superposition?: string;
  geometry?: string;
  pointType?: string;
  metrics?: RawMetrics;
  induction?: string;
  inversion?: string;
}

export interface GdeyaAdapterOptions {
  subjectId: string;
  sessionId: string;
  context?: Context;
  impact?: Impact;
  owner?: string;
  position?: Position;
  explicitAuthorization?: boolean;
}

const PLATE_SET = new Set<string>(["РЕСУРС", "ВЛАСТЬ", "ОТНОШЕНИЯ", "РЕЗУЛЬТАТ"]);
const POINT_SET = new Set<string>(["Разрыв", "Залипание", "Вход", "Интеграция"]);
const GEOMETRY_SET = new Set<string>(["Euclid", "Lobachevsky", "Riemann", "Projective", "Supra"]);

function requireValue<T>(value: T | undefined | null, label: string): T {
  if (value === undefined || value === null || value === "") throw new Error(`GDEYA entry: ${label} is required`);
  return value;
}

export function gdeyaEntryToEngineInput(entry: GdeyaDiaryEntry, options: GdeyaAdapterOptions): EngineInput {
  const plate = requireValue(entry.plate, "plate");
  if (!PLATE_SET.has(plate)) throw new Error("GDEYA entry: plate is invalid");
  if (!CONTEXTS.includes(options.context ?? "personal")) throw new Error("GDEYA adapter: context is invalid");
  const states = (entry.states ?? []).map((state) => String(state).trim()).filter(Boolean);
  const intention = [entry.card?.process, ...states, entry.superposition].filter(Boolean).join(" — ") || "Интегрировать запись ГДЕЯ";
  const pointType = entry.pointType && POINT_SET.has(entry.pointType) ? entry.pointType as PointType : undefined;
  const geometry = entry.geometry && GEOMETRY_SET.has(entry.geometry) ? entry.geometry as Geometry : undefined;
  return {
    subjectId: options.subjectId,
    sessionId: options.sessionId,
    intention,
    plate: plate as Plate,
    ...(entry.card?.id ? { cardId: entry.card.id } : {}),
    ...(entry.az?.id ? { azId: entry.az.id } : {}),
    ...(entry.buka?.id ? { bukaId: entry.buka.id } : {}),
    ...(entry.tx?.id ? { transmissionId: entry.tx.id } : {}),
    ...(pointType ? { pointType } : {}),
    ...(geometry ? { geometry } : {}),
    ...(options.position ? { position: options.position } : {}),
    induction: entry.induction ?? states.join(" | "),
    inversion: entry.inversion ?? entry.superposition ?? "",
    ...(entry.card?.process ? { objectLabel: entry.card.process } : {}),
    metrics: entry.metrics ?? {},
    context: options.context ?? "personal",
    impact: options.impact ?? "draft",
    explicitAuthorization: options.explicitAuthorization ?? false,
    ...(options.owner ? { owner: options.owner } : {}),
    metadata: { source: "gdeya-diary", legacyTimestamp: entry.ts ?? null, legacyRoman: entry.card?.roman ?? null, legacyArabic: entry.card?.arabic ?? null }
  };
}

export function parseGdeyaDiaryJson(json: string): GdeyaDiaryEntry[] {
  const value: unknown = JSON.parse(json);
  if (!Array.isArray(value)) throw new Error("GDEYA diary JSON must contain an array");
  return value as GdeyaDiaryEntry[];
}
