import type { NormalizedInput, Phase, Position } from "./types.js";

export type ManifestationState = "vacuum" | "wave" | "particle" | "field";
export interface ResolvedState {
  manifestation: ManifestationState;
  phase: Phase;
  position: Position;
  inductionActive: boolean;
  inversionActive: boolean;
  coherence: number;
  rationale: string[];
}

const PHASE_POSITION: Record<Phase, Position> = { point: "P1", architect: "P2", creator: "P3", source: "P4" };
const POSITION_PHASE: Record<Position, Phase> = { P1: "point", P2: "architect", P3: "creator", P4: "source" };

export function resolveState(input: NormalizedInput): ResolvedState {
  const coherence = Math.round(((input.metrics.alpha + input.metrics.Q + input.metrics.T) / 3) * 1000) / 1000;
  const inductionActive = Boolean(input.induction?.trim());
  const inversionActive = Boolean(input.inversion?.trim());
  const phase = input.phase ?? (input.position ? POSITION_PHASE[input.position] : "point");
  const position = input.position ?? PHASE_POSITION[phase];
  let manifestation: ManifestationState;
  if (!inductionActive && !inversionActive && coherence < 0.5) manifestation = "vacuum";
  else if (coherence >= 0.75 && input.objectLabel?.trim()) manifestation = "particle";
  else if (inductionActive !== inversionActive || input.metrics.T >= 0.75) manifestation = "wave";
  else manifestation = "field";
  return { manifestation, phase, position, inductionActive, inversionActive, coherence, rationale: [`coherence=${coherence}`, `induction=${inductionActive}`, `inversion=${inversionActive}`] };
}
