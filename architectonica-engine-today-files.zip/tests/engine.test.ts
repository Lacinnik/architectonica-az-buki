import { describe, expect, it } from "vitest";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { ArchitectonicaEngine, AZ, BUKI, CARDS, CREATOR_CELLS, CREATOR_OPERATIONS, CollectiveEngine, ENGINE_VERSION, GdeyaEngineController, JsonFileStore, LocalStorageStore, MemoryStore, STORE_SCHEMA_VERSION, TRANSMISSIONS, VERSION_MANIFEST, assertCatalogIntegrity, gdeyaEntryToEngineInput, migrateStoreState, normalizeMetrics, parseGdeyaDiaryJson, type EngineInput, type SharedField } from "../src/index.js";

let id = 0;
const makeEngine = () => new ArchitectonicaEngine({ store: new MemoryStore(), makeId: () => `id-${++id}`, now: () => new Date("2026-07-11T00:00:00Z") });
const valid = (overrides: Partial<EngineInput> = {}): EngineInput => ({ subjectId: "subject-1", sessionId: "session-1", intention: "Создать точную форму", plate: "РЕСУРС", pointType: "Вход", metrics: { alpha: 0.75, IY: 0.75, Cm: 0.75, Q: 0.75, T: 0.75 }, context: "personal", impact: "draft", ...overrides });

describe("normalization", () => {
  it("accepts comma decimals and IЯ alias", () => expect(normalizeMetrics({ alpha: "0,75", "IЯ": "1", Cm: 0.5, Q: 1, T: 0 })).toEqual({ alpha: 0.75, IY: 1, Cm: 0.5, Q: 1, T: 0 }));
  it("rejects metrics outside 0..1", () => expect(() => normalizeMetrics({ alpha: 2, IY: 1, Cm: 1, Q: 1, T: 1 })).toThrow(/alpha/));
});

describe("persistent stores", () => {
  it("restores LocalStorage data in a new store instance", async () => {
    const values = new Map<string, string>();
    const storage = { getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => { values.set(key, value); } };
    const first = new ArchitectonicaEngine({ store: new LocalStorageStore(storage), makeId: () => `id-${++id}` });
    const decision = await first.evaluate(valid({ eventId: "persistent-browser-event" }));
    await first.recordOutcome({ sessionId: "session-1", eventId: "persistent-browser-event", decisionId: decision.decisionId, successScore: 0.8 });
    const restored = new LocalStorageStore(storage);
    expect(await restored.listEvents("session-1")).toHaveLength(1);
    expect(await restored.listOutcomes("session-1")).toHaveLength(1);
  });

  it("atomically persists and restores file data", async () => {
    const directory = await mkdtemp(join(tmpdir(), "architectonica-"));
    const path = join(directory, "engine.json");
    try {
      const engine = new ArchitectonicaEngine({ store: new JsonFileStore(path), makeId: () => `id-${++id}` });
      await engine.evaluate(valid({ eventId: "persistent-file-event" }));
      await engine.evaluate(valid({ eventId: "persistent-file-event" }));
      expect((await new JsonFileStore(path).listEvents("session-1"))).toHaveLength(1);
      expect(JSON.parse(await readFile(path, "utf8")).schemaVersion).toBe(STORE_SCHEMA_VERSION);
    } finally { await rm(directory, { recursive: true, force: true }); }
  });
  it("restores full Chronos profile and outcomes with the session", async () => {
    const values = new Map<string, string>();
    const storage = { getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => { values.set(key, value); } };
    const first = new ArchitectonicaEngine({ store: new LocalStorageStore(storage), makeId: () => `id-${++id}` });
    const decision = await first.evaluate(valid({ eventId: "feedback-source" }));
    await first.recordOutcome({ sessionId: "session-1", eventId: "feedback-source", decisionId: decision.decisionId, successScore: 1 });
    const resumed = new ArchitectonicaEngine({ store: new LocalStorageStore(storage), makeId: () => `id-${++id}` });
    const calibrated = await resumed.evaluate(valid({ eventId: "after-resume" }));
    expect(calibrated.chronos?.profile).toMatchObject({ lastUpdatedAt: expect.any(String) });
    expect(await resumed.store.listOutcomes("session-1")).toHaveLength(1);
  });
  it("migrates schema v1 without losing accumulated arrays", () => {
    const migrated = migrateStoreState({ schemaVersion: 1, events: [{ eventId: "legacy" }], decisions: [], outcomes: [] }, "2026-07-11T00:00:00.000Z");
    expect(migrated).toMatchObject({ schemaVersion: STORE_SCHEMA_VERSION, engineVersion: ENGINE_VERSION, createdAt: "2026-07-11T00:00:00.000Z" });
    expect(migrated.events).toHaveLength(1);
  });
  it("refuses a future unknown schema", () => expect(() => migrateStoreState({ schemaVersion: 99 })).toThrow(/newer/));
});

describe("GDEYA adapter", () => {
  const legacy = { ts: "11.07.2026", plate: "РЕСУРС", card: { id: "R-01", process: "БАЗОВЫЕ ПОТРЕБНОСТИ", roman: "I", arabic: 1 }, states: ["опора"], az: { id: "A1", title: "Азъ" }, buka: { id: "B1", title: "Суперпозиция" }, tx: { id: "TX3", title: "Резонанс" }, superposition: "тело ⊕ образ", geometry: "Euclid", pointType: "Вход", metrics: { alpha: "0,75", IY: "0,75", Cm: "0,75", Q: "0,75", T: "0,75" } };
  it("maps a legacy diary entry to a valid Engine input", async () => {
    const input = gdeyaEntryToEngineInput(legacy, { subjectId: "subject", sessionId: "import" });
    const decision = await makeEngine().evaluate(input);
    expect(decision.allow).toBe(true);
    expect(decision.normalizedInput?.metadata?.source).toBe("gdeya-diary");
  });
  it("passes explicit public authorization into Engine", async () => {
    const input = gdeyaEntryToEngineInput(legacy, { subjectId: "subject", sessionId: "public", context: "public", explicitAuthorization: true });
    expect((await makeEngine().evaluate(input)).allow).toBe(true);
  });
  it("parses an exported diary array", () => expect(parseGdeyaDiaryJson(JSON.stringify([legacy]))).toHaveLength(1));
  it("rejects a non-array export", () => expect(() => parseGdeyaDiaryJson("{}" )).toThrow(/array/));
});

describe("CollectiveEngine", () => {
  const metrics = { alpha: 0.8, Q: 0.8, T: 0.8, IY: 0.8, Cm: 0.8 };
  const field = (overrides: Partial<SharedField> = {}): SharedField => ({ id: "field-1", subjectIds: ["a", "b"], trustLinks: [{ from: "a", to: "b", object: "agreement" }, { from: "b", to: "a", object: "agreement" }], sharedObjects: [{ label: "A", createdBy: "a", metrics }, { label: "B", createdBy: "b", metrics }], ...overrides });
  it("allows synthesis with mutual trust, contribution and metrics", () => expect(new CollectiveEngine().evaluate(field()).gate).toBe("ok"));
  it("reports exactly the missing directed trust link", () => expect(new CollectiveEngine().evaluate(field({ trustLinks: [{ from: "a", to: "b", object: "one-way" }] })).missingTrustLinks).toEqual([{ from: "b", to: "a" }]));
  it("classifies missing contribution as sync failure", () => expect(new CollectiveEngine().evaluate(field({ sharedObjects: [{ label: "A", createdBy: "a", metrics }] })).gate).toBe("sync"));
  it("classifies insufficient conductance as metrics failure", () => expect(new CollectiveEngine().evaluate(field({ sharedObjects: [{ label: "A", createdBy: "a", metrics: { ...metrics, alpha: 0.2 } }, { label: "B", createdBy: "b", metrics }] })).gate).toBe("metrics"));
});

describe("Collective gate in ArchitectonicaEngine", () => {
  const metrics = { alpha: 0.8, Q: 0.8, T: 0.8, IY: 0.8, Cm: 0.8 };
  const completeField: SharedField = { id: "shared-main", subjectIds: ["a", "b"], trustLinks: [{ from: "a", to: "b", object: "contract" }, { from: "b", to: "a", object: "contract" }], sharedObjects: [{ label: "A", createdBy: "a", metrics }, { label: "B", createdBy: "b", metrics }] };
  it("passes collective gate inside the main pipeline", async () => {
    const decision = await makeEngine().evaluate(valid({ sharedField: completeField }));
    expect(decision.allow).toBe(true);
    expect(decision.collective).toMatchObject({ gate: "ok", synthesisReady: true });
    expect(decision.gateResults.at(-1)?.gate).toBe("collective");
  });
  it("blocks main pipeline when mutual trust is incomplete", async () => {
    const decision = await makeEngine().evaluate(valid({ sharedField: { ...completeField, trustLinks: completeField.trustLinks.slice(0, 1) } }));
    expect(decision).toMatchObject({ allow: false, gate: "collective", status: "blocked" });
    expect(decision.collective?.missingTrustLinks).toEqual([{ from: "b", to: "a" }]);
  });
  it("never materializes a collectively denied decision", async () => {
    const execution = await makeEngine().execute(valid({ sharedField: { ...completeField, sharedObjects: completeField.sharedObjects.slice(0, 1) } }));
    expect(execution.decision.collective?.gate).toBe("sync");
    expect(execution.artifact).toBeUndefined();
  });
});

describe("GdeyaEngineController", () => {
  const entry = { ts: "11.07.2026 12:00", plate: "РЕСУРС", card: { id: "R-01", process: "БАЗОВЫЕ ПОТРЕБНОСТИ" }, states: ["опора"], az: { id: "A1" }, buka: { id: "B1" }, tx: { id: "TX3" }, pointType: "Вход", metrics: { alpha: 0.75, IY: 0.75, Cm: 0.75, Q: 0.75, T: 0.75 } };
  it("imports a complete diary through the Engine", async () => {
    const controller = new GdeyaEngineController(makeEngine(), { subjectId: "subject", sessionId: "diary" });
    const result = await controller.importJson(JSON.stringify([entry, { ...entry, ts: "11.07.2026 12:01" }]));
    expect(result).toMatchObject({ total: 2, allowed: 2, denied: 0, invalid: 0 });
  });
  it("executes one UI entry and returns a Creator artifact", async () => {
    const controller = new GdeyaEngineController(makeEngine(), { subjectId: "subject", sessionId: "diary", position: "P4" });
    const execution = await controller.executeEntry(entry);
    expect(execution.artifact?.cell.key).toBe("4A");
    expect(execution.artifact?.domain).toBe("environment");
  });
  it("records outcome feedback from a UI decision", async () => {
    const engine = makeEngine();
    const controller = new GdeyaEngineController(engine, { subjectId: "subject", sessionId: "diary" });
    const decision = await controller.evaluateEntry(entry);
    const outcome = await controller.recordOutcome(decision, 1, "переход завершён");
    expect(outcome).toMatchObject({ successScore: 1, notes: "переход завершён" });
    expect(await engine.store.listOutcomes("diary")).toHaveLength(1);
  });
  it("builds a subject memory snapshot", async () => {
    const engine = makeEngine();
    const controller = new GdeyaEngineController(engine, { subjectId: "subject", sessionId: "diary" });
    const decision = await controller.evaluateEntry(entry);
    await controller.recordOutcome(decision, 0.5);
    const memory = await controller.getMemorySnapshot();
    expect(memory.counts).toEqual({ events: 1, decisions: 1, outcomes: 1, allowed: 1, denied: 0 });
    expect(memory.transmissions.TX3).toMatchObject({ decisions: 1, outcomes: 1, averageSuccess: 0.5 });
    expect(memory.manifestations.particle).toBe(1);
  });
});

describe("canonical catalog", () => {
  it("contains the canonical 96/49/24/7 sets", () => {
    expect(() => assertCatalogIntegrity()).not.toThrow();
    expect([CARDS.length, AZ.length, BUKI.length, TRANSMISSIONS.length]).toEqual([96, 49, 24, 7]);
  });
  it("rejects unknown catalog identifiers", async () => expect((await makeEngine().evaluate(valid({ azId: "A50" }))).status).toBe("invalid"));
  it("keeps every card inside its plate", () => expect(CARDS.every((card) => card.id.startsWith({ "РЕСУРС": "R", "ВЛАСТЬ": "P", "ОТНОШЕНИЯ": "C", "РЕЗУЛЬТАТ": "O" }[card.plate]))).toBe(true));
});

describe("ArchitectonicaEngine", () => {
  it("allows a complete personal draft and recommends transmission", async () => {
    const decision = await makeEngine().evaluate(valid());
    expect(decision.allow).toBe(true);
    expect(decision.gate).toBe("ok");
    expect(decision.recommendedTransmission).toBe("TX3");
    expect(decision).toMatchObject({ engineVersion: VERSION_MANIFEST.engine, policyVersion: VERSION_MANIFEST.policy, catalogVersion: VERSION_MANIFEST.catalog, storeSchemaVersion: VERSION_MANIFEST.storeSchema });
  });
  it("denies unknown context before metric gates", async () => {
    const decision = await makeEngine().evaluate(valid({ context: "unknown" }));
    expect(decision.status).toBe("halted");
    expect(decision.gate).toBe("governance");
  });
  it("stops on critical risk", async () => expect((await makeEngine().evaluate(valid({ risk: "critical" }))).gate).toBe("negative"));
  it("blocks insufficient angelic conductance", async () => expect((await makeEngine().evaluate(valid({ metrics: { alpha: 0.5, IY: 1, Cm: 1, Q: 0.5, T: 0.5 } }))).gate).toBe("angelic"));
  it("returns validation decision instead of throwing", async () => expect((await makeEngine().evaluate(valid({ intention: "" }))).status).toBe("invalid"));
  it("does not duplicate an event id", async () => {
    const store = new MemoryStore();
    const engine = new ArchitectonicaEngine({ store, makeId: () => `id-${++id}` });
    await engine.evaluate(valid({ eventId: "same" }));
    await engine.evaluate(valid({ eventId: "same" }));
    expect(store.events).toHaveLength(1);
  });
  it("attaches Chronos trajectory to a decision", async () => {
    const decision = await makeEngine().evaluate(valid({ induction: "Я собираю внутреннюю опору и удерживаю направление", inversion: "отклик" }));
    expect(["T_self", "T_social", "hybrid"]).toContain(decision.chronos?.trajectoryType);
    expect(decision.chronos?.continuationProbability).toBeGreaterThan(0);
    expect(decision.chronos?.state).toMatchObject({ conductance: expect.any(Number), delta: expect.any(Number) });
  });
  it("resolves manifestation and phase state", async () => {
    const decision = await makeEngine().evaluate(valid({ phase: "creator", induction: "внутренний поток", inversion: "внешний поток", objectLabel: "форма" }));
    expect(decision.resolvedState).toMatchObject({ phase: "creator", position: "P3", inductionActive: true, inversionActive: true, manifestation: "particle" });
  });
  it("detects a repeated transition loop", async () => {
    const engine = makeEngine();
    const repeated = { transmissionId: "TX3", metrics: { alpha: 0.1, IY: 0.1, Cm: 0.1, Q: 0.1, T: 0.1 } } as const;
    await engine.evaluate(valid(repeated));
    await engine.evaluate(valid(repeated));
    await engine.evaluate(valid(repeated));
    const fourth = await engine.evaluate(valid(repeated));
    expect(fourth.chronos?.loop).toBe("repetition");
  });
  it("records an outcome linked to its decision", async () => {
    const engine = makeEngine();
    const decision = await engine.evaluate(valid());
    const outcome = await engine.recordOutcome({ sessionId: "session-1", eventId: decision.normalizedInput!.eventId, decisionId: decision.decisionId, successScore: 0.9 });
    expect(outcome.successScore).toBe(0.9);
    expect(await engine.store.listOutcomes("session-1")).toHaveLength(1);
  });
  it("rejects an outcome for an unknown decision", async () => {
    await expect(makeEngine().recordOutcome({ sessionId: "s", eventId: "e", decisionId: "missing", successScore: 1 })).rejects.toThrow(/decisionId/);
  });
  it("materializes only an allowed decision", async () => {
    const execution = await makeEngine().execute(valid({ position: "P3", objectLabel: "Карта движка" }));
    expect(execution.artifact?.cell.key).toBe("3A");
    expect(execution.artifact?.domain).toBe("environment");
    expect(execution.artifact?.specification.title).toBe("Карта движка");
    expect(execution.artifact?.sourceDecisionId).toBe(execution.decision.decisionId);
  });
  it("implements all 16 Creator cells and operations", async () => {
    expect(Object.keys(CREATOR_CELLS)).toHaveLength(16);
    expect(Object.keys(CREATOR_OPERATIONS)).toHaveLength(16);
    const positions = ["P1", "P2", "P3", "P4"] as const;
    const plates = ["РЕСУРС", "ВЛАСТЬ", "ОТНОШЕНИЯ", "РЕЗУЛЬТАТ"] as const;
    const expectedDomains = ["environment", "people", "structures", "forms"];
    for (let row = 0; row < positions.length; row += 1) for (let column = 0; column < plates.length; column += 1) {
      const execution = await makeEngine().execute(valid({ position: positions[row]!, plate: plates[column]! }));
      expect(execution.artifact?.cell.key).toBe(`${row + 1}${String.fromCharCode(65 + column)}`);
      expect(execution.artifact?.domain).toBe(expectedDomains[column]);
      expect(execution.artifact?.domainResult.operation).toBe(execution.artifact?.operation.opType);
    }
  });
  it("does not materialize a denied decision", async () => {
    const execution = await makeEngine().execute(valid({ context: "unknown" }));
    expect(execution.decision.allow).toBe(false);
    expect(execution.artifact).toBeUndefined();
  });
});
